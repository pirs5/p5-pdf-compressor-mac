Pirs 5 PDF Compressor - macOS arm64 build

Run from Terminal:
  ./Pirs5PDFCompressor

Keep the bundle folder next to the executable:
  Pirs5PDFCompressor_PDFCompressorApp.bundle
